﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TimeDocLog
{
    public partial class CustomerRegistration : Form
    {
        public CustomerRegistration()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void currency_TextChanged(object sender, EventArgs e)
        {

        }

        private void payRate_TextChanged(object sender, EventArgs e)
        {

        }

        private void paymentMethod_TextChanged(object sender, EventArgs e)
        {

        }

    }
}
